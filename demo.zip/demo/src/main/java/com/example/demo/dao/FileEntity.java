package com.example.demo.dao;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="demo")
public class FileEntity {
    @Id
    @Column(name = "row_id", columnDefinition = "varchar(50)")
    private String rowId;

    @Column(name = "content", columnDefinition = "varchar(1000)")
    private String content;

}
