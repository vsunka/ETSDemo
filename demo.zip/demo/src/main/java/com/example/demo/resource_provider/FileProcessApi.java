package com.example.demo.resource_provider;

import com.example.demo.service.FileProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FileProcessApi {

    @Autowired
    private FileProcessor fileProcessor;
    @PostMapping(value="/example/demo/fileprocess",produces = "application/json",consumes="application/json")
    public ResponseEntity fileProcess(@RequestBody String filePath){
        fileProcessor.processFile(filePath);
        return ResponseEntity.status(HttpStatus.ACCEPTED)
                .headers(HttpHeaders.EMPTY)
                .body("File Persisted");
    }
}
