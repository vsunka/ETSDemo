package com.example.demo.service;

import com.example.demo.dao.FileEntity;
import com.example.demo.dao.FileReposiotry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

@Service
public class FileProcessor {
    @Autowired
    FileReposiotry repository;

    @Autowired
    FileEntity entity;

    public void processFile(String fileName){
        try(Scanner input = new Scanner(fileName)){

            while(input.hasNextLine()){
                String line = input.nextLine();
                FileEntity entity = new FileEntity();
                //persist to DB

                repository.save(entity);
            }
        }catch(Exception e){

        }


    }
    //Save Data to DB
    private void saveToDB()
    {
        try(Connection con = connect();
            PreparedStatement stmt = con.prepareStatement("INSERT INTO FILE_DB VALUES (?,?)")){

        }catch(SQLException e){
            System.out.println(e);
        }
    }

    //Get DB Connection
    private Connection connect()
    {
       try{

           Class.forName("com.mysql.jdbc.driver");

           return DriverManager.getConnection("jdbc:mysql://localhost:3306/dbName","username","password");


       }catch (ClassNotFoundException | SQLException e){
           System.out.println(e);
            return null;
       }
    }
}
