package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;

import java.sql.*;
import java.util.UUID;


public class TransactionPersistHandler {

    @Autowired
    TransactionEntity transactionEntity;

    public void persistTransactionData(String userID, String transactionDate, int amount){
        transactionEntity.setTransactionId(UUID.randomUUID().toString());
        transactionEntity.setUserId(userID);
        transactionEntity.setTransactionDate(transactionDate);
        transactionEntity.setTransactionamount(amount);

        //Persist UserId, TransactionDate and A TransactionID  to A
        // Transaction ID is the primary key in table A and used as foreign key in table B .

        persistToA(transactionEntity);

        //Store transactionAmount and TransactionID in Table B
        persistToB(transactionEntity);

        //Store TOtal transactionAmount and UserID in Table C

        retrieveAndUpdateInfoInC(transactionEntity);

    }

    public void persistToA(TransactionEntity entity){

        try(Connection con = connect();
            PreparedStatement ps = con.prepareStatement("INSERT INTO TABLE_A VALUES (?,?,?)")){
            ps.setString(1,entity.getTransactionId());
            ps.setString(2,entity.getUserId());
            ps.setString(3,entity.getTransactionDate());
            ps.executeUpdate();

        }catch(SQLException e){
            System.out.println(e);
        }

    }

    public void persistToB(TransactionEntity entity){

        try(Connection con = connect();
            PreparedStatement ps = con.prepareStatement("INSERT INTO TABLE_B VALUES (?,?)")){
            ps.setString(1,entity.getTransactionId());
            ps.setInt(2,entity.getTransactionamount());

            ps.executeUpdate();

        }catch(SQLException e){
            System.out.println(e);
        }
    }

    public void retrieveAndUpdateInfoInC(TransactionEntity entity){
        try{
            Connection con = connect();

            PreparedStatement ps = con.prepareStatement("select userid,TransactionAmt from TABLE_C where USer_id =?");
            ps.setString(1,entity.getUserId());
            ResultSet rs = ps.executeQuery();
            //First transaction
            if(rs == null)
            {
                PreparedStatement stmt = con.prepareStatement("INSERT INTO TABLE_C VALUES (?,?)");
                ps.setString(1,entity.getUserId());
                ps.setInt(2,entity.getTransactionamount());

                stmt.executeUpdate();
            }
            else{
                PreparedStatement stmt = con.prepareStatement("INSERT INTO TABLE_C VALUES (?,?)");
                ps.setString(1,entity.getUserId());
                ps.setInt(2,(entity.getTransactionamount()+rs.getInt(2)));

                stmt.executeUpdate();
            }

        }catch(SQLException e){
            System.out.println(e);
        }
    }


    //Get DB Connection
    private Connection connect()
    {
        try{

            Class.forName("com.mysql.jdbc.driver");

            return DriverManager.getConnection("jdbc:mysql://localhost:3306/dbName","username","password");


        }catch (ClassNotFoundException | SQLException e){
            System.out.println(e);
            return null;
        }
    }
}
