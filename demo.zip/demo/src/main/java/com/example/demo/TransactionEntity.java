package com.example.demo;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Id;
import java.util.Date;

@Data
@Getter
@Setter
@NoArgsConstructor
public class TransactionEntity {

    @Id
    private String transactionId;
    private String userId;
    private String transactionDate;
    private int transactionamount;
}
