package com.example.demo.dao;

import org.springframework.data.repository.CrudRepository;

public interface FileReposiotry  extends CrudRepository<FileEntity, Long> {

}
