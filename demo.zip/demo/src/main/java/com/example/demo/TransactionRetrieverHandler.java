package com.example.demo;

import java.sql.*;

public class TransactionRetrieverHandler {

    private String UserID;

    public void retrieveUserTransactionInfo(String userId){

        try {
            Connection con = connect();

           PreparedStatement ps = con.prepareStatement("select TOP 1 b.TransactionAmt,a.transactionDate, c.totalAmount  from TABLE_A a " +
                    "JOIN  TABLE_B b ON A.TRANSACTION_ID = B.TRANSACTION_ID " +
                    "JOIN  TABLE_C c ON C.USER_ID = A.USER_ID  where USer_id =? ORDER BY A.transacationDate DESC");


            /*PreparedStatement ps = con.prepareStatement("select TOP 1 b.TransactionAmt,a.transactionDate from TABLE_A a , TABLE_B b where USer_id =? and A.TRANSACTION_ID = B.TRANSACTION_ID ORDER BY A.transacationDate DESC)";*/

            ps.setString(1, userId);
            ResultSet rs = ps.executeQuery();
            //First transaction
            if (rs != null) {
                System.out.println("Recent transactionDate:" + rs.getString(2));
                System.out.println("Last transactionAmount:" + rs.getString(1));
                System.out.println("Total  transactionAmount:" + rs.getString(3));
            }
        }catch(SQLException e){
            System.out.println(e);
        }


    }

    private Connection connect()
    {
        try{

            Class.forName("com.mysql.jdbc.driver");

            return DriverManager.getConnection("jdbc:mysql://localhost:3306/dbName","username","password");


        }catch (ClassNotFoundException | SQLException e){
            System.out.println(e);
            return null;
        }
    }
}
